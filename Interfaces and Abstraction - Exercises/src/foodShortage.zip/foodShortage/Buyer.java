package foodShortage;

public interface Buyer extends Person {
    void buyFood();
    int getFood();
}
