package militaryElite.interfaces;

public interface Spy {
    String getCodeNumber();
}
