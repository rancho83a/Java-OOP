package defineanInterfacePerson;

public interface Person {
    String getName();
    int getAge();
}
